let tasks = [];

window.onload = function () {
  loadTasks();
  displayTasks();
};

function loadTasks() {
  let stored = localStorage.getItem("tasks");
  if (stored) {
    tasks = JSON.parse(stored);
  }
}

function saveTasks() {
  localStorage.setItem("tasks", JSON.stringify(tasks));
}

// CREATE
function addTask() {
  let input = document.getElementById("taskInput");
  let text = input.value.trim();

  if (text === "") {
    alert("Please enter a task!");
    return;
  }

  tasks.push(text);
  saveTasks();
  displayTasks();

  input.value = "";
}

// READ
function displayTasks() {
  let list = document.getElementById("taskList");
  list.innerHTML = "";

  tasks.forEach((task, index) => {
    let li = document.createElement("li");
    li.innerHTML = `
      ${task}
      <div class="btn-group">
        <button class="editBtn" onclick="editTask(${index})">Edit</button>
        <button class="deleteBtn" onclick="deleteTask(${index})">Delete</button>
      </div>
    `;
    list.appendChild(li);
  });
}

// UPDATE
function editTask(index) {
  let newTask = prompt("Edit your task:", tasks[index]);
  if (newTask !== null && newTask.trim() !== "") {
    tasks[index] = newTask.trim();
    saveTasks();
    displayTasks();
  }
}

// DELETE
function deleteTask(index) {
  tasks.splice(index, 1);
  saveTasks();
  displayTasks();
}
